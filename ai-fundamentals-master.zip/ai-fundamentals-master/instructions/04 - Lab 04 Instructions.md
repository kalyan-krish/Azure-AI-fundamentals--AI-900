# AI-900 Labs
## 04 - Lab 04 Instructions
In this lab we will create an application that can understand language. 

### Tasks
1.	Start Visual Studio Code and open the ai-fundamentals project.
2.	Open the **02d - Language Understanding.ipynb** notebook.
3.	Follow the instructions in the notebook to complete the lab.
