cd /usr/bin
echo -n "Ready to Go. Refresh the browser to start!"