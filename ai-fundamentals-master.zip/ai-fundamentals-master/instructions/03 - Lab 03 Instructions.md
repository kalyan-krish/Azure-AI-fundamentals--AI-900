# AI-900 Labs
## 03 - Lab 03 Instructions
In this lab we will be using the Custom Vision service in Azure to identify real-world items based on images.

### Tasks
1.	Start Visual Studio Code by clicking on the icon in the taskbar.
2.  Open the **01b - Image Classification.ipynb** notebook.
3.  Follow the instructions in the notebook to complete the lab.
