# Microsoft Learn AI Fundamentals Exercises

The sample code in this repository is for use in hands-on exercises that support preparation for the [Microsoft Azure AI Fundamentals certification](https://docs.microsoft.com/learn/certifications/azure-ai-fundamentals).


## Contributing

At this time, we are not accepting contributions to this repository. If you encounter an issue with the exercises, please [report it](https://docs.microsoft.com/learn/support/troubleshooting#report-feedback).
